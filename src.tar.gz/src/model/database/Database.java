package model.database;

public class Database {

}
