package model.game;

public enum Box {
	BLOCK, GROUND, DOOR, PLAYER, EMPTY, PLAYER_ON_DOOR
}
