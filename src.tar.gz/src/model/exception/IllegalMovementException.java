package model.exception;

public class IllegalMovementException extends Exception {
	private static final long serialVersionUID = 4962049892439505340L;

}
