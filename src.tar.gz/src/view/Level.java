package view;

import java.io.IOException;
import java.util.ArrayList;

import model.game.Action;
import model.game.Box;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
 
public class Level extends BasicGameState {
    private StateBasedGame game;
    private GameContainer container;
    
    private model.game.Level l = null;
    private Image back, ground, player, box, door;

    public void init(GameContainer gc, StateBasedGame sbg) throws SlickException {
        this.container = gc;
        this.game = sbg;
        back = new Image("ressources/teeworlds-data/mapres/mountains.png");
        ground = new Image("ressources/ground.png");
        player = new Image("ressources/alex.png");
        box = new Image("ressources/box.png");
        door = new Image("ressources/door.png");
    }
	
    public void render(GameContainer gc, StateBasedGame sbg, Graphics g) throws SlickException {
        /*ArrayList<ArrayList<Box>> a = l.getMap();
        int px = l.getP().getX(), py = l.getP().getY();
        for (int y = py - 7; y < py + 6; ++y) {
            for (int x = px - 5; x < px + 5; ++x) {
                if (y >= 0 && y < a.size() && x >= 0 && x < a.get(y).size()) {
                    switch(a.get(y).get(x)) {
                        case GROUND : ground.draw((x - 7) * 64,y * 64); break;
                        case PLAYER : player.draw((x - 7) * 64,y * 64); break;
                        case BLOCK : box.draw((x - 7) * 64,y * 64); break;
                        case DOOR : door.draw((x - 7) * 64,y * 64); break;
                        case PLAYER_ON_DOOR : g.drawString("T'as gagné pauv'con (" + l.getNbMoves() + ")", 150, 150); break;
                    }  
                }
            }
        }*/
        
       int y = 0;
        for(ArrayList<Box> c: l.getMap())
        {
            int x = 0;
            for(Box m: c){
                switch(m) {
                    case GROUND : ground.draw(x,y); break;
                    case PLAYER : player.draw(x,y); break;
                    case BLOCK : box.draw(x,y); break;
                    case DOOR : door.draw(x,y); break;
                    case PLAYER_ON_DOOR : game.enterState(0); break;
                }
                x += ground.getWidth();
            }
            y += ground.getHeight();
        }
    }
 
    public void update(GameContainer gc, StateBasedGame sbg, int arg2) throws SlickException { }
	
	public void setLevel(Integer level){
	    try {
            l = new model.game.Level("maps/" + level);
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	public void keyPressed(int key, char c) {
	    Action a = null;
	    switch (key) {
	        case Input.KEY_ESCAPE : game.enterState(0); break;
	        case Input.KEY_UP : a = Action.UP; break;
	        case Input.KEY_DOWN : a = Action.DOWN; break;
	        case Input.KEY_LEFT : a = Action.LEFT; break;
	        case Input.KEY_RIGHT : a = Action.RIGHT; break;
	    }
	    if (a != null) {
            try {
                l.action(a);
            } catch (Exception e) {
            }
	    }
	}

    public int getID() {
        return 1;
    }
}