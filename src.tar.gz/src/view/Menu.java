package view;


public class Menu {

}
